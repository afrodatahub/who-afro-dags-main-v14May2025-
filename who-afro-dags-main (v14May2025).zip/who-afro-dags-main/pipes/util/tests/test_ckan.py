def test_test_ckan():
    assert True
