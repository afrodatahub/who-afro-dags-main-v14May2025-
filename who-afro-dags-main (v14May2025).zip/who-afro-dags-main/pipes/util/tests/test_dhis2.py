def test_test_dhis2():
    assert True
