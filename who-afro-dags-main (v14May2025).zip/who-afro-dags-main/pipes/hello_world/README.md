# Hello World Pipeline

This is a simple pipeline that prints "Hello World!" to the console in various log levels.
