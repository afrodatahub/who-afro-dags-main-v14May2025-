### Building

Commits to the `master` branch will automatically be built and pushed to the staging environment. Tags will be built and pushed to the production environment. You can manually run [the pipeline](https://dev.azure.com/AFDATAHUB/AFDATAHUB/_build?definitionId=4) for any commit to build and push to the either environment.

Deployment is manual, by running the pipeline [here](https://dev.azure.com/AFDATAHUB/AFDATAHUB)
