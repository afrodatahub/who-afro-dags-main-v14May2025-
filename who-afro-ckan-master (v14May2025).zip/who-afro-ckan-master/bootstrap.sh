#!/bin/sh
# build js components & allow editing
